$(document).ready(function() {
    alert("está a funcionar");
})