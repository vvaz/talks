$(document).ready(function() {
    
    // pergunta 1
    $('.box').css('color', '#fff');

    $('.box').html('Forma de declarar uma <strong>Strong</strong>');
    
    $('.box').text('Forma de declarar uma <div>');

    $('.box').addClass('novaClass');






    // editar as ULs
/*
    $('li.azul').css('background', 'blue');
    $('li.verde').css('background', 'green');
    $('li.vermelho').css('background', 'red');


    // botão

    $('button').css({'background': 'green', 'color': 'white'});

    // IDs

    $('.lione').css({'background':'pink', 'font-size': '30px'});
    $('#litwo').css({'color': '#000', 'font-size': '30px', 'background': 'green'});
    $('#lithree').css({'color': 'blue', 'font-size': '20px', 'background':'red', 'padding': '2rem'});
*/

});