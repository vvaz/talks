// WebStorage
// localStorage
// sessionStorage

// JSON


// metodos
// setItem getItem
// clear();
// removeItem ();

localStorage.setItem('Melhor Filme', 'Green Book');
localStorage.setItem('Melhor Actor', 'Rami Malek');
