$('.trigger').on('click', function() {
	$(this).toggleClass('clicked');
});


$('.box2').on('click', function() {
	$(this).toggleClass('is-paused');
});