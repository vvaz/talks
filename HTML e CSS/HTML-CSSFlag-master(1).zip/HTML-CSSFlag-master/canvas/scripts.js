var canvas = document.getElementById("canvas1");

var ctx = canvas.getContext("2d");

ctx.fillStyle = "#ffcc00";
ctx.fillRect(50, 40, 100, 30);